import React from 'react'
import { FaFacebook,FaLinkedin,FaInstagram } from "react-icons/fa6";
import { MdMonitorHeart } from "react-icons/md";
export const Services = () => {
  return (
    <div className='w-[100vw]' id='services'>
        <div className='px-5'>
            <h1>Services</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum, repellendus! Numquam, ducimus! Ut explicabo minus suscipit temporibus, </p>
        </div>
    <div className='grid md:grid-cols-2 lg:grid-cols-3 gap-10 w-[100vw]   px-5 py-4 '>
       
        <div className='rounded-xl shadow-lg bg-white border-2 px-4 py-5 lg:w-[85%] transition-transform transform hover:-translate-y-2 [&>'>
            <div className='mb-4'>
                <div className='w-16 h-16 bg-[#009970] rounded-full flex justify-center items-center border-2 '>
                     {/* <FaLinkedin size={24} className='text-gray-500 hover:text-[#009970]' /> */}
                     <MdMonitorHeart size={30}/>
                </div>
            </div>
            <div className='mb-2 text-lg md:text-xl lg:text-2xl  font-bold text-[#009970]'>SAS Production Monitoring System</div>
            <p className='mt-3 text-base md:text-base lg:text-lg'>
                 Alias maxime voluptate molestiae. Totam incidunt minus quod nostrum amet repellat a eum veniam facere provident temporibus consequatur, laboriosam perspiciatis, illo nihil.
            </p>
        </div>
        <div className='rounded-xl shadow-lg bg-white border-2 px-4 py-5 lg:w-[85%] transition-transform transform hover:-translate-y-2 [&>'>
            <div className='mb-4'>
                <div className='w-16 h-16 bg-[#009970] rounded-full flex justify-center items-center border-2 '>
                     {/* <FaLinkedin size={24} className='text-gray-500 hover:text-[#009970]' /> */}
                     <MdMonitorHeart size={30}/>
                </div>
            </div>
            <div className='mb-2 text-lg md:text-xl lg:text-2xl  font-bold text-[#009970]'>SAS Production Monitoring System</div>
            <p className='mt-3 text-base md:text-base lg:text-lg'>
                 Alias maxime voluptate molestiae. Totam incidunt minus quod nostrum amet repellat a eum veniam facere provident temporibus consequatur, laboriosam perspiciatis, illo nihil.
            </p>
        </div>
        <div className='rounded-xl shadow-lg bg-white border-2 px-4 py-5 lg:w-[85%] transition-transform transform hover:-translate-y-2 [&>'>
            <div className='mb-4'>
                <div className='w-16 h-16 bg-[#009970] rounded-full flex justify-center items-center border-2 '>
                     {/* <FaLinkedin size={24} className='text-gray-500 hover:text-[#009970]' /> */}
                     <MdMonitorHeart size={30}/>
                </div>
            </div>
            <div className='mb-2 text-lg md:text-xl lg:text-2xl  font-bold text-[#009970]'>SAS Production Monitoring System</div>
            <p className='mt-3 text-base md:text-base lg:text-lg'>
                 Alias maxime voluptate molestiae. Totam incidunt minus quod nostrum amet repellat a eum veniam facere provident temporibus consequatur, laboriosam perspiciatis, illo nihil.
            </p>
        </div>
        <div className='rounded-xl shadow-lg bg-white border-2 px-4 py-5 lg:w-[85%] transition-transform transform hover:-translate-y-2 [&>'>
            <div className='mb-4'>
                <div className='w-16 h-16 bg-[#009970] rounded-full flex justify-center items-center border-2 '>
                     {/* <FaLinkedin size={24} className='text-gray-500 hover:text-[#009970]' /> */}
                     <MdMonitorHeart size={30}/>
                </div>
            </div>
            <div className='mb-2 text-lg md:text-xl lg:text-2xl  font-bold text-[#009970]'>SAS Production Monitoring System</div>
            <p className='mt-3 text-base md:text-base lg:text-lg'>
                 Alias maxime voluptate molestiae. Totam incidunt minus quod nostrum amet repellat a eum veniam facere provident temporibus consequatur, laboriosam perspiciatis, illo nihil.
            </p>
        </div>
        <div className='rounded-xl shadow-lg bg-white border-2 px-4 py-5 lg:w-[85%] transition-transform transform hover:-translate-y-2 [&>'>
            <div className='mb-4'>
                <div className='w-16 h-16 bg-[#009970] rounded-full flex justify-center items-center border-2 '>
                     {/* <FaLinkedin size={24} className='text-gray-500 hover:text-[#009970]' /> */}
                     <MdMonitorHeart size={30}/>
                </div>
            </div>
            <div className='mb-2 text-lg md:text-xl lg:text-2xl  font-bold text-[#009970]'>SAS Production Monitoring System</div>
            <p className='mt-3 text-base md:text-base lg:text-lg'>
                 Alias maxime voluptate molestiae. Totam incidunt minus quod nostrum amet repellat a eum veniam facere provident temporibus consequatur, laboriosam perspiciatis, illo nihil.
            </p>
        </div>
        <div className='rounded-xl shadow-lg bg-white border-2 px-4 py-5 lg:w-[85%] transition-transform transform hover:-translate-y-2 [&>'>
            <div className='mb-4'>
                <div className='w-16 h-16 bg-[#009970] rounded-full flex justify-center items-center border-2 '>
                     {/* <FaLinkedin size={24} className='text-gray-500 hover:text-[#009970]' /> */}
                     <MdMonitorHeart size={30}/>
                </div>
            </div>
            <div className='mb-2 text-lg md:text-xl lg:text-2xl  font-bold text-[#009970]'>SAS Production Monitoring System</div>
            <p className='mt-3 text-base md:text-base lg:text-lg'>
                 Alias maxime voluptate molestiae. Totam incidunt minus quod nostrum amet repellat a eum veniam facere provident temporibus consequatur, laboriosam perspiciatis, illo nihil.
            </p>
        </div>
        
       
      
        
              
    </div>

    
    </div>
  )
}
