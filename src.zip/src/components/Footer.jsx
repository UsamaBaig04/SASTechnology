import React from 'react'
import { AiOutlineYoutube } from "react-icons/ai";
import { FaFacebook,FaLinkedin,FaInstagram } from "react-icons/fa6";

export const Footer = () => {
  return (
    <div className='w-[100vw] bg-slate-100 px-5 pb-4 mt-5'>
        <div className='lg:flex'>
            <div className=' p-3 lg:w-[45%]'>
                <h3>SAS TECHNOLOGY</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur asperiores impedit ratione repudiandae, </p>
                <div className='flex gap-x-5'>
                <div className='w-11 h-11  rounded-full flex justify-center items-center border-2 border-gray-500 hover:border-[#009970] hover:text-[#009970]'>
                    <AiOutlineYoutube size={24} className='text-gray-500 hover:text-[#009970]' />
                </div>
                <div className='w-11 h-11  rounded-full flex justify-center items-center border-2 border-gray-500 hover:border-[#009970] hover:text-[#009970]'>
                    <FaFacebook size={24} className='text-gray-500 hover:text-[#009970]' />
                </div>
                <div className='w-11 h-11  rounded-full flex justify-center items-center border-2 border-gray-500 hover:border-[#009970] hover:text-[#009970]'>
                    <FaInstagram size={24} className='text-gray-500 hover:text-[#009970]' />
                </div>
                <div className='w-11 h-11  rounded-full flex justify-center items-center border-2 border-gray-500 hover:border-[#009970] hover:text-[#009970]'>
                    <FaLinkedin size={24} className='text-gray-500 hover:text-[#009970]' />
                </div>
                    
                </div>
            </div>
            <div className='grid grid-cols-2 lg:grid-cols-3  lg:w-[50%] pt-2'>
                <div>
                    <h5 className='p-2'>Useful Links</h5>
                    <ul className='[&>li]:leading-7 lg:text-base [&>li]:hover:cursor-pointer'>
                        <li className='hover:text-[#009970]'>Home</li>
                        <li className='hover:text-[#009970]'>About Us</li>
                        <li className='hover:text-[#009970]'>Services</li>
                        <li className='hover:text-[#009970]'>Products</li>
                        <li className='hover:text-[#009970]'>Contacts</li>
                    </ul>
                </div>
                <div>
                <h5 className='p-2 '>Our Services</h5>
                <ul className='[&>li]:leading-7 lg:text-base '>
                        <li className='hover:text-[#009970] hover:cursor-pointer'>Home</li>
                        <li className='hover:text-[#009970] hover:cursor-pointer'>About Us</li>
                        <li className='hover:text-[#009970] hover:cursor-pointer'>Services</li>
                        <li className='hover:text-[#009970] hover:cursor-pointer'>Products</li>
                        <li className='hover:text-[#009970] hover:cursor-pointer'>Contacts</li>
                    </ul>
                </div>
                <div className=' md:pl-2 '>
                <h5 className='lg:p-2'>Contact Us</h5>
               <p>A108 Adam Street, New York, NY 535022</p>
               <p className='leading-[.7rem] lg:leading-3'><span className='font-bold'>Phone:</span> +91 123456789</p>
               <p className='leading-[.7rem] lg:leading-3'><span className='font-bold'>Email:</span> sastechnology.in</p>
                </div>
            </div>
        </div>
        <div className='flex flex-col w-[100%]  items-center bg-slate-200 justify-center py-2'>
            <p>&copy; Copyright <span className='text-[#009970] font-semibold '>SAS Technology</span> All Rights Reserved</p>
            <p className='md:leading-[.1rem]'>Designed by <span className='text-[#009970] font-semibold'>SAS Technology</span></p>
        </div>
    </div>
  )
}
