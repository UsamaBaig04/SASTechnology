import React,{useEffect, useRef, useState } from 'react'
import Isotope from 'isotope-layout';
import abb from '../images/abb.png';
import redlion from '../images/redlion.png'
export const Products = () => {
    const isotope = useRef(null);
  const [filterKey, setFilterKey] = useState('*');

  useEffect(() => {
    // Initialize Isotope after component mounts
    isotope.current = new Isotope('.isotope-container', {
      itemSelector: '.portfolio-item',
      layoutMode: 'masonry',
      filter: '*',
    });
    return () => isotope.current.destroy();
  }, []);

  useEffect(() => {
    if (isotope.current) {
      isotope.current.arrange({ filter: filterKey });
    }
  }, [filterKey]);

  const handleFilter = (key) => {
    setFilterKey(key);
  };
  return (
    <div className="px-5 w-[100vw] mt-5">
        <div>
            <h1>Products</h1>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Animi </p>
        </div>
      {/* Filter buttons */}
      <ul className="flex justify-center space-x-10  mb-0 lg:text-xl font-semibold">
        <li
          className={`cursor-pointer ${filterKey === '*' ? 'text-[#009970]' : ''} hover:text-[#009970]`}
          onClick={() => handleFilter('*')}
        >
          All
        </li>
        <li
          className={`cursor-pointer ${filterKey === '.filter-abb' ? 'text-[#009970]' : ''} hover:text-[#009970]`}
          onClick={() => handleFilter('.filter-abb')}
        >
          ABB
        </li>
        <li
          className={`cursor-pointer ${filterKey === '.filter-product' ? 'text-[#009970]' : ''} hover:text-[#009970]`}
          onClick={() => handleFilter('.filter-product')}
        >
          RedLion
        </li>
        <li
          className={`cursor-pointer ${filterKey === '.filter-branding' ? 'text-[#009970]' : ''} hover:text-[#009970]`}
          onClick={() => handleFilter('.filter-branding')}
        >
          HMS
        </li>
        <li
          className={`cursor-pointer ${filterKey === '.filter-books' ? 'text-[#009970]' : ''} hover:text-[#009970]`}
          onClick={() => handleFilter('.filter-books')}
        >
          PcVue
        </li>
        <li
          className={`cursor-pointer ${filterKey === '.filter-books' ? 'text-[#009970]' : ''} hover:text-[#009970]`}
          onClick={() => handleFilter('.filter-books')}
        >
          Klemsan
        </li>
        <li
          className={`cursor-pointer ${filterKey === '.filter-books' ? 'text-[#009970]' : ''} hover:text-[#009970]`}
          onClick={() => handleFilter('.filter-books')}
        >
          Inovance
        </li>
        <li
          className={`cursor-pointer ${filterKey === '.filter-books' ? 'text-[#009970]' : ''} hover:text-[#009970]`}
          onClick={() => handleFilter('.filter-books')}
        >
          Kntech
        </li>
      </ul>

      {/* Portfolio grid */}
      <div className="isotope-container grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10  h-auto px-5 pt-4 pb-5">
        {/* Portfolio Items */}
        {/* Abb items starts here */}
       
        <div className="portfolio-item filter-abb bg-red-100 shadow-lg lg:w-[25vw] ">
          <div className="portfolio-content h-auto">
            <img src={abb} alt="ABB 1" className="w-full h-[70%]" />
            <div className="px-4 py-2">
              <h4 className="text-lg font-semibold">ABB-1</h4>
              <p>Lorem ipsum, dolor sit amet consectetur</p>
            </div>
          </div>
        </div>
        <div className="portfolio-item filter-abb bg-red-100 shadow-lg lg:w-[25vw]">
          <div className="portfolio-content h-auto">
            <img src={abb} alt="ABB 1" className="w-full h-[70%]" />
            <div className="p-4">
              <h4 className="text-lg font-semibold">ABB-1</h4>
              <p>Lorem ipsum, dolor sit amet consectetur</p>
            </div>
          </div>
        </div>
        <div className="portfolio-item filter-abb bg-red-100 shadow-lg lg:w-[25vw]">
          <div className="portfolio-content h-auto">
            <img src={abb} alt="ABB 1" className="w-full h-[70%]" />
            <div className="p-4">
              <h4 className="text-lg font-semibold">ABB-1</h4>
              <p>Lorem ipsum, dolor sit amet consectetur</p>
            </div>
          </div>
        </div>
         {/* Abb items ends here */}
         {/* Redlion items starts here */}
        
        <div className="portfolio-item filter-abb bg-red-100 shadow-lg lg:w-[25vw]">
          <div className="portfolio-content h-auto">
            <img src={redlion} alt="redlion 1" className="w-full h-[70%]" />
            <div className="p-4">
              <h4 className="text-lg font-semibold">ABB-1</h4>
              <p>Lorem ipsum, dolor sit amet consectetur</p>
            </div>
          </div>
        </div>
             {/* Redlion items ends here */}

       

        {/* <div className="portfolio-item filter-product">
          <div className="portfolio-content">
            <img src="assets/img/portfolio/product-1.jpg" alt="Product 1" className="w-full h-auto" />
            <div className="p-4">
              <h4 className="text-lg font-semibold">Product 1</h4>
              <p>Lorem ipsum, dolor sit amet consectetur</p>
            </div>
          </div>
        </div>

        <div className="portfolio-item filter-branding">
          <div className="portfolio-content">
            <img src="assets/img/portfolio/branding-1.jpg" alt="Branding 1" className="w-full h-auto" />
            <div className="p-4">
              <h4 className="text-lg font-semibold">Branding 1</h4>
              <p>Lorem ipsum, dolor sit amet consectetur</p>
            </div>
          </div>
        </div> */}

        {/* Add more portfolio items as needed */}
      </div>
    </div>
  )
}
