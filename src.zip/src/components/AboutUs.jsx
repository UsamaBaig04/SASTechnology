import React from 'react'
import assa from '../images/aboutUs.jpg'
export const AboutUs = () => {
  return (
    <div className=' grid lg:grid-cols-2 pt-5 place-items-center px-5' id='about'>
        <div className='lg:w-[40vw] lg:h-[55vh] md:w-[80vw] md:h-[60vh] lg:order-last md:order-first'>
            <img src={assa} className='w-[100%] h-[100%]'/>
        </div>

        <div className='lg:order-first md:order-first md:mt-5 mt-3'>
            <h3 className='text-[1.5rem] md:text-[2rem] lg:text-[2.5rem]'>About Us</h3>
            <p className='md:text-md lg:text-xl  tracking-normal'>SAS Automation Pvt Ltd has been serving various industries for over a 
                decade, establishing itself as a trusted partner in delivering innovative 
                and efficient solutions. Our in-depth understanding of the diverse needs 
                of our clients, combined with extensive experience, enables us to provide 
                comprehensive services tailored to meet specific industry requirements. 
                We take pride in offering a wide range of services designed to support 
                our esteemed clients in achieving their business goals. Our business 
                offerings include:</p>
            
                <ul className='grid md:grid-cols-2 lg:grid-cols-2 pt-2 md:text-sm lg:text-lg'> 
              <li>
                <div className='[&>h5]:text-lg md:[&>h5]:text-lg lg:[&>h5]:text-xl'>
                  <h5> Design & Engineering Services.</h5>
                  <p>Magni facilis facilis repellendus cum excepturi quaerat praesentium libre trade</p>
                </div>
              </li>
              <li>
                
                <div className='[&>h5]:text-lg md:[&>h5]:text-lg lg:[&>h5]:text-xl'>
                  <h5>Customized Product Development.</h5>
                  <p>Quo totam dolorum at pariatur aut distinctio dolorum laudantium illo direna pasata redi</p>
                </div>
              </li>
              <li>
                
                <div className='[&>h5]:text-lg md:[&>h5]:text-lg lg:[&>h5]:text-xl'>
                  <h5>Panel Engineering & Manufacturing.</h5>
                  <p>Et velit et eos maiores est tempora et quos dolorem autem tempora incidunt maxime veniam</p>
                </div>
              </li>
              <li>
             
                <div className='[&>h5]:text-lg md:[&>h5]:text-lg lg:[&>h5]:text-xl'>
                  <h5> Turnkey Project Support.</h5>
                  <p>Et velit et eos maiores est tempora et quos dolorem autem tempora incidunt maxime veniam</p>
                </div>
              </li>
              <li>
               
                <div className='[&>h5]:text-lg md:[&>h5]:text-lg lg:[&>h5]:text-xl'>
                  <h5> IoT-based Solutions.</h5>
                  <p>Et velit et eos maiores est tempora et quos dolorem autem tempora incidunt maxime veniam</p>
                </div>
              </li>
              <li>
                
                <div className='[&>h5]:text-lg md:[&>h5]:text-lg lg:[&>h5]:text-xl'>
                  <h5>PLC/SCADA System Design</h5>
                  <p>Et velit et eos maiores est tempora et quos dolorem autem tempora incidunt maxime veniam</p>
                </div>
              </li>
            </ul>
        </div>
    </div>
  )
}
