import React from 'react'
export const Contacts = () => {
  return (
    <div className='md:p-5 lg:p-5 px-3' id='contacts'>
        <h1 className='px-5'>Contact</h1>
        <p className='px-5'>Lorem ipsum dolor sit amet, </p>
    
        <div className=' lg:flex lg:gap-8 md:px-5 lg:px-2 lg:ml-5 w-[100vw]   pb-2'>
            <div className=' lg:w-[40%] w-[95%] md:w-[100%] p-5 md:shadow-lg lg:shadow-2xl md:border-2 border-2 shadow-md  mt-4 '>
            
                <div> 
                    <h4>Address</h4>
                    <p>A108 Adam Street, New York, NY 535022</p>
                </div>
                <div>
                    <h4>Call Us</h4>
                    <p>+91 123456789</p>
                </div>
                <div>
                    <h4>Email Us</h4>
                    <p>sastechnology.in</p>
                </div>
                <div className='lg:w-[100%]'>
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d48389.78314118045!2d-74.006138!3d40.710059!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a22a3bda30d%3A0xb89d1fe6bc499443!2sDowntown%20Conference%20Center!5e0!3m2!1sen!2sus!4v1676961268712!5m2!1sen!2sus" frameborder="0" style={{border:0,width:'100%',height:'270px'}} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
            <div className='lg:w-[50%] w-[95%] md:w-[100%] md:shadow-lg lg:shadow-2xl p-5 lg:text-xl md:text-md  md:border-2 border-2 shadow-md mt-4 lg:mt-0'>
                <form>
                   
                   <div className='md:flex lg:flex  w-[100%]'>
                    <div className=' md:w-1/2 lg:w-1/2 h-[12vh] '>
                        <label className='mb-2'>Your Name</label><br/>
                        <input type="text" name="name" required=""  className='border-2 h-[50%] w-[100%] md:w-[95%] lg:w-[95%]'/>
                    </div>
                    <div className='md:w-1/2 h-[12vh] '>
                        <label className='mb-2'>Your Email</label><br/>
                        <input type="text" name="email" required=""  className='border-2 h-[50%] w-[100%] md:w-[95%] lg:w-[95%] md:ml-4 lg:ml-4 '/>
                    </div>
                    </div>
                    <div className='w-full mt-2  h-[12vh]'>
                        <label className='mb-2'>Subject</label><br/>
                        <input type="text" name="subject" required="" className='border-2 w-[100%] h-[50%]'/>
                    </div>
                    <div className=' mt-2 h-[30vh]'>
                        <label className='mb-2'>Message</label><br/>
                        <input type="text" name="subject" required="" className='border-2 w-[100%] h-[90%] '/>
                    </div>
                    
                    <div className=' flex justify-center mt-4'>
                        <button className='bg-[#009970] rounded-2xl px-4 py-2 text-white'>Send Message</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
  )
}
