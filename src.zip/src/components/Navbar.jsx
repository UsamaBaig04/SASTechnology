import React from 'react'
import { RxHamburgerMenu } from "react-icons/rx";
export const Navbar = () => {
  return (
    <div className='navContainer flex items-center w-[90vw] h-[9vh]   text-sm md:text-md lg:text-lg  fixed top-10 z-50 ml-16 bg-white'>
        <div className='bg-[#009970] w-[30%] md:w-[20%] lg:w-[20%] h-[100%] flex items-center justify-center text-[.8rem] md:text-[.9rem] lg:text-2xl text-white'>SAS TECHNOLOGY</div>
        <div className='flex justify-end   w-[80%] h-[100%]'>
          <ul className='justify-evenly items-center w-[80%] h-[100%] sm:flex hidden font-semibold cursor-pointer'>
            <li className='md:text-md hover:text-[#009970]'>
            <a href='#home' className='text-gray-700 no-underline hover:text-[#009970]'>HOME</a>
            </li>
            <li className='md:text-md hover:text-[#009970]'>
            <a href='#about' className='text-gray-700 no-underline hover:text-[#009970]'>ABOUT</a>
            </li>
            <li className='md:text-md hover:text-[#009970]'>
            <a href='#services' className='text-gray-700 no-underline hover:text-[#009970]'>SERVICES</a>

            </li>
            <li className='md:text-md hover:text-[#009970]'>PRODUCTS</li>
            <li className='md:text-md hover:text-[#009970]'>
            <a href='#contacts' className='text-gray-700 no-underline hover:text-[#009970]'>CONTACTS</a>
            </li>
          </ul>
            <div className='flex items-center h-[100%]'>
            <button className='bg-[#009970] rounded-3xl text-white px-3 mr-2 py-2'>Get Started</button>
            <div className='md:hidden px-2'><RxHamburgerMenu size={30}/></div>
            </div>
        </div>
    </div>
  )
}
